package kr.codemakers.oracle.tool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OracleVoMakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
