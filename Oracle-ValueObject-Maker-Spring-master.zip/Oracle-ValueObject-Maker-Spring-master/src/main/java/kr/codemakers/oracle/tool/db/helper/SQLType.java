package kr.codemakers.oracle.tool.db.helper;

public enum SQLType {

	SELECT, INSERT, UPDATE, DELETE;
	
}
