package kr.codemakers.oracle.tool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleVoMakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OracleVoMakerApplication.class, args);
	}

}
